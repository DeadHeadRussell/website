var fs = require('fs');
var data = {};

exports.getData = function(callback) {
    fs.readFile('../Client/resumes/' + data.resumes[0].path + '_part.html', 'ascii', function(error, fdata) {
        if(error) {
            callback(null);
        } else {
            data.resumes[0].data = fdata;
            callback(data);
        }
    });
};

data.about = {
    name: 'Andrew Russell',
    title: 'Musician and Software Engineering Student'
};

data.intro =
  'You have found yourself where humankind was not meant to venture. ' +
  'Depths unknown to all but a few. Few who would rather not speak of ' +
  'the dark places they had once been. What will be seen cannot be ' +
  'unseen. What will be heard cannot be unheard. What awaits is beyond ' +
  'describing. Horrors so aweful that they will leave you scarred for ' +
  'life. Seething and twisting, you will be wrenched to the floor, ' +
  'screaming in pain from the abominations. Considered yourself warned; ' +
  'you have found my personal website.';

data.contact = {
    email: 'deadhead.russell@gmail.com'
};

data.sites = [
  {
    name: 'West Coast Drinking Expedition',
    link: 'http://wcdrinkingexpedition.ajrussell.ca',
    desc: 'Blog that details the West Coast Drinking Expedition I attended'
  },
  {
    name: 'Baryons for Breakfast',
    link: 'http://baryonsforbreakfast.wordpress.com',
    desc: 'My sister\'s delicious cooking blog'
  },
  {
    name: 'Noah Sugarman\'s Personal Website',
    link: 'http://noahsug.com',
    desc: 'A fellow software engineering student\'s website that hosts all of the awesome web and mobile games that he has created.'
  },
  {
    name: 'Andrew Munn\'s Blog',
    link: 'http://andrewmunn.com',
    desc: 'Andrew Munn talks about his experience at the UWaterloo co-op program in his well written blog.'
  },
  {
    name: 'Stephan Pastis\'s Blog',
    link: 'http://stephanpastis.wordpress.com',
    desc: 'Personal blog of the creator of the syndicated comic \'Pearls Before Swine\'.'
  }
];

data.artists = [
    {
        name: 'Solo Works',
        start: '1990-07-21',
        description: 'My own solo endevours. From solo live vocal/ guitar performances to full band studio recordings, most of my musical endevours have been solo efforts.',
        albums: [
            {
                name: 'YouTube',
                description: 'Check out my YouTube channel. I have many videos of me playing both covers and original songs.',
                link: 'http://www.youtube.com/user/DeadHeadRussell',
                songs: []
            },
            {
                name: 'MIDI',
                description: 'A collection of works that use MIDI patches for the bass and drums with real instruments recorded ontop',
                songs: [
                    {
                        name: 'What Am I?',
                        description: 'A four piece instrumental tune. The guitar starts off with a sweeping melody, charges through a dynamic solo, then returns to the melody for a mellow finish.',
                        recording: true
                    },
                    {
                        name: 'Mellow Song',
                        description: 'This song was co-written with my sister, Heather Russell. It is the closest to a standard pop song that I have written. The music and lyrics have a distinct mellow feel, making the listener just want to relax.',
                        recording: true
                    },
                    {
                        name: 'Die Die Die',
                        description: 'A funk trio. This song contains two very distinct styles, one that involes the lead guitar playing the melody with a warm fuzz distortion, and the other that has the guitar with a cleaner tone while the vocals have the melody.',
                        recording: true
                    },
                    {
                        name: 'Jazzy #5',
                        description: 'A change in tone, this instrumental piece has a guitar led melody, with both the guitar and piano having solos in the middle.',
                        recording: true
                    },
                    {
                        name: 'KOR Waltz',
                        description: 'Even though this song is a waltz, it won\'t fail to rock you out of this world.',
                        recording: true
                    }
                ]
            },
            {
                name: 'Epic',
                description: 'The most brilliant rock album no one has ever heard.',
                songs: [
                    {
                        name: 'hehehe...',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'The Journey',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Epic Story',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Change',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'I See',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Deleted',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Now',
                        description: '',
                        recording: true
                    }
                ]
            },
            {
                name: 'This World',
                description: 'A rock album with a theme centered around the world we all live on.',
                songs: [
                ]
            }
        ]
    },
    {
        name: 'The Cam Jervis Experience',
        start: '2008-01-01',
        end: '2008-09-01',
        description: 'For the last year in high school, my friends and I formed a band. I was on lead guitar, and played keys and sang vocals for some tracks. We rocked out at various local venues, benefit concerts and battle of the bands. While we played a couple original songs, we mainly played covers.',
        albums: [
            {
                name: 'Songs',
                description: 'Originals and covers played by The Cam Jervis Experience',
                songs: [
                    {
                        name: 'Road to Want',
                        description: 'An original progressive rock song. The idea was originated by Adam Baigent and each band member added his own touch.',
                        recording: true
                    },
                    {
                        name: 'On Either Side',
                        description: 'An original song.  Music by Adam Baigent, lyrics by Garry Garneau',
                        recording: true
                    },
                    {
                        name: 'Farmhouse',
                        description: 'A rock ballad by the band Phish.',
                        recording: true
                    },
                    {
                        name: 'El Scorcho',
                        description: 'A rock song by Weezer.',
                        recording: true
                    }
                ]
            }
        ]
    },
    {
        name: 'The Orfs',
        start: '2009-05-01',
        end: '2010-10-01',
        description: 'While I was the pianist in the University of Waterloo\'s Stage Band, the stage band\'s guitarist invited me to play with his band. The Orfs, a pyscedelic rock band, is led by Grant Kouzechar who writes most of the music we play. The rest of the songs are covers from various artists. I played the keys in this band using a number of sounds ranging from the piano to the organ and even the clavicord.',
        albums: [
            {
                name: 'Live - 26.11.09 - Maxwell\'s Music House',
                description: 'Live recording of a performance at Maxwell\'s Music House in Waterloo, Ontario.',
                songs: [
                    {
                        name: 'One Foot in the Graveyard',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Baby It\'s You',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Walk My Way',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'One Night Stand',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Lipstick On My Collar',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Bring a Woman to Me',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Unrequited Love',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Keep on Rocking',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Moma\'s Gone Insane',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Cosmic Dragons',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Sailing Alone',
                        description: '',
                        recording: true
                    },
                    {
                        name: 'Maggot Brains',
                        description: '',
                        recording: true
                    }
                ]
            }
        ]
    }
];

data.equipment = [
    {
        name: 'Guitars',
        equipment: [
            {
                name: 'Fender Stratocaster',
                description: 'I bought this guitar specifically for its neck. Compared to many other guitars that I tried at the time, this guitar had the best feel of them all. It is the Japan make 50th Anniversairy Edition Stratocaster. Japan ade Stratocasters are known for their well crafted necks, but usually have really poor wiring. As a result, I had to have the wiring touched up many times. This became a nuisance and in early 2010, I had the entire wiring replaced. Since then, I have not had a single issue with any of the electronic components.'
            },
            {
                name: 'Seagull S6+ Spruce',
                description: ''
            }
        ]
    },
    {
        name: 'Guitar Pedals',
        equipment: [
            {
                name: 'Ibenez TS9 Tubescreamer',
                description: ''
            },
            {
                name: 'Electro-Harmonix Little Big Pi Muff',
                description: ''
            },
            {
                name: 'Boss CS-3 Compressor',
                description: ''
            },
            {
                name: 'Digitech Whammy',
                description: ''
            },
            {
                name: 'Dunlop Cry Baby Wah',
                description: ''
            },
            {
                name: 'Ernie Ball VP Junior Volume Pedal',
                description: ''
            },
            {
                name: 'Boss RC-20XL Loop Station',
                description: ''
            }
        ]
    },
    {
        name: 'Guitar Amplifiers',
        equipment: [
            {
                name: 'Marshall MG 30FX',
                description: ''
            }
        ]
    },
    {
        name: 'Keyboards',
        equipment: [
            {
                name: 'Yamaha CP300 Stage Piano',
                description: ''
            },
            {
                name: 'Yamaha FC2 Sustain Pedal',
                description: ''
            },
            {
                name: 'Volume Pedal of some kind or another...',
                description: ''
            }
        ]
    },
    {
        name: 'Mixing Boards',
        equipment: [
            {
                name: 'Steinberg MI4',
                description: ''
            },
            {
                name: 'Yamaha MW12 USB Mixing Studio',
                description: ''
            }
        ]
    },
    {
        name: 'Microphones',
        equipment: [
            {
                name: 'Samson CO2 Pencil Microphones',
                description: ''
            },
            {
                name: 'Vocal Microphones',
                description: 'Shure SM58S Vocal Microphone, Apex 381 Vocal Microphone'
            },
            {
                name: 'Drum Microphones',
                description: 'Shure PG 56 Drum Microphone x3, Shure PG 52 Bass Drum Microphone'
            },
        ]
    }
];


data.resumes = [
    { path: 'current' }
];

data.softwareProjects = [
    {
        name: 'Personal Website',
        description: 'I built this website to experiment with node.js. node.js is "Evented I/O for V8 JavaScript" which includes server communication. My goal when building this website was to minimalize the JavaScript server code and put the focus instead on the client JavaScript. All of the transitions, animations and stylings seen on this website are possible due to new CSS 3 technologies. The audio playback is also enabled through the HTML 5 audio tag. All text content is passed in the original call to the server, and is formed as HTML on demand using JavaScript.'
    },
    {
        name: 'Defend Your Castle',
        description: 'Lovingly ripped off of the popular flash game. The goal of this game is to kill all of the attacking stick figures by dropping them from a great hight, before they knock down your castle.',
    },
    {
        name: 'Soccer Simulator',
        description: ''
    },
    {
        name: 'Carz',
        description: ''
    },
    {
        name: 'Conway\'s Game of Life',
        description: ''
    },
    {
        name: 'Pong',
        description: 'Pong, teh awesome game. Implemented with C++ and OpenGL. What more can be said??'
    },
    {
        name: 'Hearts',
        description: 'During my first workterm, I decided to learn perl. I created the card game hearts as a learning exercise. I completed playing single player, although the AI is very basic, and not all invalid input is handled properly.'
    }
];

