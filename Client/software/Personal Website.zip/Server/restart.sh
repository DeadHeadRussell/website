killall node
nohup node main.js &

