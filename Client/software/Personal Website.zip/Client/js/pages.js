var CreatePageHandler = function(node, pages, init) {
    var subPages = location.pathname.split('/');
    subPages.shift();
    var initPage = subPages.shift();
    if(initPage !== '') {
        init = initPage;
    }

    var page = null;

    var main = document.createElement('Div');
    main.className = 'Main';
    node.appendChild(main);

    var header = CreateHeader(pages, select, init, subPages);
    var audioPlayer = CreateAudioPlayer();

    node.insertBefore(header.node, main);
    node.appendChild(audioPlayer.getNode());

    window.addEventListener('popstate', popState, false);

    obj = {
        gotoPage: function(id, subPages) {
            header.select(id, subPages);
        },
        pushState: pushState,
        replaceState: replaceState,
        audioPlayer: audioPlayer
    };

    return obj;

    function modifyState(id, subPages, functionName) {
        var url = '/' + id;
        if(subPages && subPages.length > 0) {
            url += '/' + subPages.join('/');
        }
        if(history[functionName]) {
            history[functionName](
                { id: id, subPages: subPages },
                escape(id),
                escape(url)
            );
        }
    }

    function pushState(id, subPages) {
        modifyState(id, subPages, 'pushState');
   }

    function replaceState(id, subPages) {
        modifyState(id, subPages, 'replaceState');
    }

    function popState(e) {
        var s = e.state;
        if(s && s.id) {
            header.select(s.id, s.subPages, true);
        }
        return true;
    }

    function select(id, callback) {
        var newPage = pages[id].page;
        if(page) {
            transition.fade(
                main, newPage.node,
                function(status) {
                    if(status == transition.SUCCESS) {
                        page = newPage;
                    }
                    if(callback) {
                        callback(status);
                    }
                }
            );
        } else {
            main.appendChild(newPage.node);
            page = newPage;
            callback(transition.STARTING);
            replaceState(id, newPage.subPages);
        }
    }
};

var CreateHomePage = function() {
    var node = document.createElement("Div");

    var elems = [
        {id: 'music', title: 'Music', path: '/music', imgSrc: '/img/music/main.jpg'},
        {id: 'soft', title: 'Software', path: '/soft',  imgSrc: '/img/soft/main.jpg'},
        {id: 'about', title: 'About', path: '/about', imgSrc: '/img/about/main.jpg'}
    ];

    var content = document.createElement('Div');
    content.className = 'home';

    var head = document.createElement('Div');
    head.className = 'head';
    var h1 = document.createElement('H1');
    h1.appendChild(document.createTextNode('Welcome.'));
    head.appendChild(h1);
    var intro = document.createElement('Div');
    intro.appendChild(document.createTextNode(data.intro));
    head.appendChild(intro);
    content.appendChild(head);

    var links = CreateBoxView(elems, goToPage);
    content.appendChild(links);

    var sitesList = [];
    for(var i = 0; i < data.sites.length; i++) {
        var site = data.sites[i];
        var siteNode = document.createElement('Div');
        var titleNode = document.createElement('Div');
        var linkNode = document.createElement('A');
        linkNode.appendChild(document.createTextNode(site.name));
        linkNode.href = site.link;
        linkNode.setAttribute('target', '_blank');
        titleNode.appendChild(linkNode);
        siteNode.appendChild(titleNode);
        var descNode = document.createElement('Div');
        descNode.appendChild(document.createTextNode(site.desc));
        siteNode.appendChild(descNode);
        sitesList.push({
            id: site.name,
            node: siteNode
        });
    }
    var sites = CreateList('Awesome Sites', sitesList);
    sites.className += ' sites';
    content.appendChild(sites);

    var contactEmail = {
        id: 'contactEmail',
        node: document.createElement('A')
    };
    contactEmail.node.appendChild(document.createTextNode(data.contact.email));
    contactEmail.node.href = 'mailto:' + data.contact.email;
    var contact = CreateList('Contact', [ contactEmail ]);
    contact.className += ' contact';
    content.appendChild(contact);

    node.appendChild(content);

    var obj = {
        node: node,
        subPages: [],
        changeSubPage: function(subPages, samePage, noState) {
            obj.subPages = [];
            if(!noState) {
                pages.pushState('home', obj.subPages);
            }
        }
    };

    return obj;

    function goToPage(elem) {
        pages.gotoPage(elem.id);
        return true;
    }
};

var CreateMusicPage = function() {
    var currentArtists = [];
    var previousArtists = [];
    for(var i = 0; i < data.artists.length; i++) {
        var artist = data.artists[i];
        var artistNode = document.createElement("Div");
        artistNode.className = 'artist';

        var aImg = document.createElement("Img");
        aImg.src = '/img/music/' + artist.name + '/main.jpg';
        aImg.alt = '';
        artistNode.appendChild(aImg);
        var text = document.createElement("Div");
        text.appendChild(document.createTextNode(artist.description));
        artistNode.appendChild(text);
        
        for(var j = 0; j < artist.albums.length; j++) {
            var album = artist.albums[j];
            var content = document.createElement('Div');

            var img = document.createElement('Img');
            img.addEventListener(
                'error',
                function(e) {
                    e.target.parentNode.removeChild(e.target);
                },
                false
            );
            img.src = '/img/music/' + artist.name + '/' + album.name + '.png';
            img.alt = '';
            content.appendChild(img);

            var div = document.createElement('Div');
            div.appendChild(document.createTextNode(album.description));
            content.appendChild(div);

            var albumNode = CreateSubSection(album.name, '', content);
            
            if (album.link) {
                var link = document.createElement('A');
                link.appendChild(document.createTextNode(album.link));
                link.href = album.link;
                link.setAttribute('target', '_blank');
                link.className = 'Content';
                albumNode.appendChild(link);
            }

            var desc = document.createElement('Div');
            desc.className = 'description';
            desc.appendChild(document.createTextNode(' '));
            desc.setAttribute('aria-live', 'polite');

            var dispDesc = function(desc) {
                return function(obj) {
                    var text = document.createElement('Div');
                    var title = document.createElement('Div');
                    title.className = "title";
                    title.appendChild(document.createTextNode(obj.text));
                    text.appendChild(title);
                    text.appendChild(document.createTextNode(obj.desc));
                    desc.replaceChild(text, desc.firstChild);
                }
            }(desc);

            var songs = [];
            for(var k = 0; album.songs && k < album.songs.length; k++) {
                var song = album.songs[k];
                var id = i + '/' + j + '/' + k;
                var node = document.createElement("Div");

                var obj = {id: id, node: node, text: song.name, desc: song.description, callback: dispDesc};

                if(song.recording) {
                    var img = document.createElement("Div");
                    img.className = 'control play';
                    img.setAttribute('role', 'button');
                    node.appendChild(img);

                    song.callback = function(img, dispDesc, obj) {
                        return function(playing) {
                            if(playing) {
                                img.className = 'control pause';
                            } else {
                                img.className = 'control play';
                            }
                            dispDesc(obj);
                        }
                    }(img, dispDesc, obj);

                    var play = function(id) {
                        return function(e) {
                            pages.audioPlayer.toggle(id);
                            return true;
                        };
                    }(id);
                    img.addEventListener('keydown', keyToClick(play), false);
                }

                var span = document.createElement("Span");
                span.appendChild(document.createTextNode(song.name));
                node.appendChild(span);

                songs.push(obj);
            }

            var songClicked = function(obj) {
                    pages.audioPlayer.toggle(obj.id);
            };

            if(album.songs && album.songs.length > 0) {
                var list = CreateList('Tracks', songs, songClicked);
                albumNode.appendChild(list);
            }
            albumNode.appendChild(desc);
            artistNode.appendChild(albumNode);
        }

        var backNode = document.createElement("Div");
        backNode.className = 'back';
        backNode.addEventListener('click', displayArtists, false);
        backNode.addEventListener('keydown', keyToClick(displayArtists), false);
        backNode.setAttribute('role', 'button');
        backNode.setAttribute('tabindex', '0');
        backNode.setAttribute('title', 'Back');

        var sectionNode = document.createElement("Div");
        sectionNode.appendChild(CreatePageTitle(artist.name));
        sectionNode.appendChild(backNode);
        sectionNode.appendChild(artistNode);
        
        var tempObj = {
            id: artist.name,
            title: artist.name,
            path: '/music/artists/' + artist.name,
            imgSrc: aImg.src,
            content: sectionNode
        };
        if(artist.end) {
            previousArtists.push(tempObj);
        } else {
            currentArtists.push(tempObj);
        }
    }

    equipments = [];
    for(var i = 0; i < data.equipment.length; i++) {
        e = data.equipment[i];
        var content = document.createElement('Div');
        for(var j = 0; j < e.equipment.length; j++) {
            var ee = e.equipment[j];
            var description = document.createElement('Div');
            var img = document.createElement('Img');
            img.src = '/img/equipment/' + e.name + '/' + ee.name + '.jpg';
            description.appendChild(img);
            var text = document.createElement('Div');
            text.appendChild(document.createTextNode(ee.description));
            description.appendChild(text);
            content.appendChild(CreateSubSection(ee.name, '', description));
        }

        var backNode = document.createElement("Div");
        backNode.className = 'back';
        backNode.addEventListener('click', displayEquipmentList, false);
        backNode.addEventListener('keydown', keyToClick(displayEquipmentList), false);
        backNode.setAttribute('role', 'button');
        backNode.setAttribute('tabindex', '0');
        backNode.setAttribute('title', 'Back');

        var sectionNode = document.createElement("Div");
        sectionNode.appendChild(CreatePageTitle(e.name));
        sectionNode.appendChild(backNode);
        sectionNode.appendChild(content);

        equipments.push({
            id: e.name,
            title: e.name,
            path: '/music/equipment/' + e.name,
            imgSrc: '/img/equipment/' + e.name + '/main.jpg',
            content: sectionNode
        });
    }

    var artistsNode = document.createElement("Div");
    artistsNode.className = 'artists';
    var artistsContent = document.createElement("Div");
    artistsNode.appendChild(artistsContent);

    var artistsListNode = document.createElement("Div");
    var currentArtistsNode  = CreateSubSection("Current Acts", "", CreateBoxView(currentArtists, displayArtist));
    var previousArtistsNode = CreateSubSection("Previous Acts", "", CreateBoxView(previousArtists, displayArtist));
    artistsListNode.appendChild(CreatePageTitle("Related Acts"));
    artistsListNode.appendChild(currentArtistsNode);
    artistsListNode.appendChild(previousArtistsNode);
    artistsContent.appendChild(artistsListNode);

    var equipmentNode = document.createElement("Div");
    equipmentNode.className = 'equipment';
    equipmentContent = document.createElement("Div");
    equipmentNode.appendChild(equipmentContent);

    var equipmentListNode = document.createElement("Div");
    var equipmentBoxView = CreateBoxView(equipments, displayEquipment);
    equipmentListNode.appendChild(CreatePageTitle("Equipment"));
    equipmentListNode.appendChild(equipmentBoxView);
    equipmentContent.appendChild(equipmentListNode);

    var nav = CreateNavigation(
        'Navigation',
        {
            artists: {title: 'Related Acts', node: artistsNode},
            equipment: {title: 'Equipment', node: equipmentNode}
        },
        '/music/',
        'artists',
        navigationPageChanged
    );

    var defaultSubPages = ['artists'];
    var obj = {
        node: nav.node,
        subPages: defaultSubPages,
        changeSubPage: function(subPages, samePage, noState) {
            if(!subPages || subPages.length < 1) {
                if(samePage) {
                    subPages = defaultSubPages;
                } else {
                    subPages = obj.subPages;
                }
            }

            if(subPages[0] == 'artists') {
                if(subPages.length > 1) {
                    var artists = currentArtists.concat(previousArtists);
                    subPages[1] = unescape(subPages[1]);
                    for(var i = 0; i < artists.length; i++) {
                        if(artists[i].title === subPages[1]) {
                            displayArtist(artists[i], samePage, noState);
                            return;
                        }
                    }
                }
                displayArtists(samePage, noState);
                return;
            } else if(subPages[0] == 'equipment') {
                if(subPages.length > 1) {
                    subPages[1] = unescape(subPages[1]);
                    for(var i = 0; i < equipments.length; i++) {
                        if(equipments[i].title === subPages[1]) {
                            displayEquipment(equipments[i], samePage, noState);
                            return;
                        }
                    }
                }
                displayEquipmentList(samePage, noState);
                return;
            }
        }
    };

    return obj;

    function display(root, elem, subPages, samePage, noState) {
        samePage = samePage !== false;
        if(!samePage) {
            root.replaceChild(elem, root.firstChild);
            nav.changePage(subPages[0], !samePage);
            obj.subPages = subPages;
            if(!noState) {
                pages.pushState('music', obj.subPages);
            }
        } else {
            transition.fade(
                root, elem,
                function(status) {
                    if(status == transition.FAILED) {
                        root.replaceChild(elem, root.firstChild);
                    }
                    if(status == transition.SUCCESS || status == transition.FAILED) {
                        nav.changePage(subPages[0], !samePage);
                    }
                    if(status == transition.FAILED || status == transition.STARTING) {
                        obj.subPages = subPages;
                        if(!noState) {
                            pages.pushState('music', obj.subPages);
                        }
                    }
                }
            );
        }
    }

    function displaySingle(root, elem, id, samePage, noState) {
        var subPages = [id, elem.title];
        display(root, elem.content, subPages, samePage, noState);
    }

    function displayArtist(elem, samePage, noState) {
        displaySingle(artistsContent, elem, 'artists', samePage, noState);
        return true;
    }

    function displayEquipment(elem, samePage, noState) {
        displaySingle(equipmentContent, elem, 'equipment', samePage, noState);
        return true;
    }

    function displayList(root, elem, id, samePage, noState) {
        var subPages = [id];
        display(root, elem, subPages, samePage, noState);
    }

    function displayArtists(samePage, noState) {
        displayList(artistsContent, artistsListNode, 'artists', samePage, noState);
    }

    function displayEquipmentList(samePage, noState) {
        displayList(equipmentContent, equipmentListNode, 'equipment', samePage, noState);
    }

    function navigationPageChanged(id, previous) {
        var root = id === 'artists' ? artistsContent : equipmentContent;
        var listChild = id === 'artists' ? artistsListNode : equipmentListNode;
        if(root.firstChild === listChild) {
            if(id != previous) {
                obj.subPages = [id];
                pages.pushState('music', obj.subPages);
            }
            return;
        }

        var child = root.children[0];

        if(id == previous) {
            if(id == 'artists') {
                displayArtists();
            } else {
                displayEquipmentList();
            }
            return;
        }

        var children = id === 'artists' ? currentArtists.concat(previousArtists) : equipments;
        for(var i in children) {
            if(child == children[i].content) {
                obj.subPages = [id, children[i].title];
                pages.pushState('music', obj.subPages);
                return;
            }
        }

        displayArtists();
    }
};

var CreateSoftPage = function() {
    var resumeNode = document.createElement('Div');
    resumeNode.className = 'resumeWrapper';
    if(data.resumes.length > 0) {
        var linkNode = document.createElement('Div');
        linkNode.className = 'resumeLink';

        var createDocLink = function(type) {
            var link = document.createElement('A');
            link.href = '/resumes/' + data.resumes[0].path + '.' + type.toLowerCase();
            link.target = '_blank';
            link.appendChild(document.createTextNode(type.toUpperCase() + ' Version'));
            return link;
        };
        linkNode.appendChild(createDocLink('html'));
        linkNode.appendChild(createDocLink('pdf'));

        resumeNode.innerHTML = data.resumes[0].data;
        resumeNode.insertBefore(linkNode, resumeNode.firstChild);
    }

    var projectsNode = document.createElement("Div");
    projectsNode.className = 'softwareProjects';
    for(var i = 0; i < data.softwareProjects.length; i++) {
        p = data.softwareProjects[i];
        var content = document.createElement('Div');

        var source = document.createElement('A');
        source.href = '/software/' + p.name + '.zip';
        source.appendChild(document.createTextNode('Source'));
        content.appendChild(source);

        var img = document.createElement('Img');
        img.src = '/img/soft/' + p.name + '.png';
        content.appendChild(img);

        var desc = document.createElement('P');
        desc.appendChild(document.createTextNode(p.description));
        content.appendChild(desc);

        projectsNode.appendChild(CreateSubSection(p.name, '', content));
    }

    var nav = CreateNavigation(
        "Navigation",
        {
            resume: { title: "Resume", node: resumeNode },
            projects: { title: "Projects", node: projectsNode }
        },
        '/soft/',
        'resume',
        onNavigationChange
    );

    var defaultSubPages = ['resume'];
    var obj = {
        node: nav.node,
        subPages: defaultSubPages,
        changeSubPage: function(subPages, samePage, noState) {
            if(!subPages || subPages.length < 1) {
                if(samePage) {
                    subPages = defaultSubPages;
                } else {
                    subPages = obj.subPages;
                }
            }

            subPages.splice(1);

            if(subPages[0] == 'projects') {
                nav.changePage(subPages[0], !samePage);
            } else {
                nav.changePage('resume', !samePage);
                subPages = ['resume'];
            }
            obj.subPages = subPages;
            if(!noState) {
                pages.pushState('soft', obj.subPages);
            }
        }
    };

    return obj;

    function onNavigationChange(id, previous) {
        if(id == previous) {
            return;
        }
        obj.subPages = [id];
        pages.pushState('soft', obj.subPages);
    }
};

var CreateAboutPage = function() {
    var node = document.createElement("Div");
    node.className = "about";
    var padding = document.createElement("Div");
    node.appendChild(padding);
    padding.appendChild(CreateSubSection('About', '', document.createTextNode("I'll be finishing this soon enough...")));

    var obj = {
        node: node,
        subPages: [],
        changeSubPage: function(subPages, samePage, noState) {
            obj.subPages = [];
            if(!noState) {
                pages.pushState('about', obj.subPages);
            }
        }
    };

    return obj;
};

