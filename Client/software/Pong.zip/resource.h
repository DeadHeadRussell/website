#define IDI_PONG    10
